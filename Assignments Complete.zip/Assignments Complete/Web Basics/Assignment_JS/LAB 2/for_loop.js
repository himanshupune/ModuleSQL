function loop1(){
for(var i=0;i<100;i++){
	document.write(i + " ");
	if(i%10==9){
		document.write("<br/>");
	}
	}
}

function loop2()
{	var j=0;
	while(j<100){
		document.write(j+ " ");
		if(j%10==9){
		document.write("<br/>");
	    }
	j++;
	}
	
}

function loop3(){
var k=0;
do{
	document.write(k+ " ");
	if(k%10==9){
		document.write("<br/>");
	}
	k++;
}while(k<100);
}