function calcInterest(){
	var p = 1000;
	var r = 10;
	var n = 1;
	var temp1 = (1+r/100);
	var temp2 = Math.pow(temp1,n);
	var temp3 = temp2*p - p;
	document.write("Compound Interest is:" + temp3);
}