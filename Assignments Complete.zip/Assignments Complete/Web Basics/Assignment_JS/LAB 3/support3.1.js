function dispTime(){
	var tDate = new Date();
	var yDate = new Date("12/15/1990");
	var weekday = new Array(7);
	
	weekday[0] =  "Sun";
	weekday[1] = "Mon";
	weekday[2] = "Tue";
	weekday[3] = "Wed";
	weekday[4] = "Thu";
	weekday[5] = "Fri";
	weekday[6] = "Sat";

	//var n = weekday[tDate.getDay()];
	//document.write(yDate.getDay());
	
	var a = tDate.getHours();
	document.write(tDate+"<br/>");
	
	if(a<12){
		document.write("Good Morning");
	}
	else if(a>=12 && a<=17){
		document.write("Good Afternoon");
	}
	else if(a>17){
		document.write("Good Evening");
	}
}