function dispString(){
	var a = 'Capgemini';
	document.write("The actual string is \v \v \v \v \v \v \v \v\v\v\v\v\v\v\v\v \v- \v \v" + a + "<br/>");
	document.write("The character to be searched for is \v \v \v \v \v  - \v \v p" + "<br/>");
	document.write("The character is found at the index \v \v \v \v \v - \v \v " + a.indexOf("p"));
}