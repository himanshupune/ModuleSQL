function dispStrAgain(){
	var str = 'University at Capgemini';
	var str1 = 'hello javascripters!'
	document.write("String is \v \v \v \v \v \v \v  \v \v\v \v \v\v \v \v \v \v  \v \v \v \v \v  \v \v \v \v \v \v \v \v  \v \v \v \v \v \v \v  \v  \v \v \v \v \v \v \v\v\v\v\v\v\v\v\v \v: \v \v" + str + "<br/>");
	document.write("Result of str.match(\'Capgemini\') \v \v \v \v \v  : \v \v " + str.match("Capgemini") + "<br/>");
	document.write("Result of str.substr(3,6) \v \v \v \v \v \v  \v \v \v \v \v \v \v \v \v \v \v  \v \v : \v \v " + str.substr(3,6) + "<br/>");
	document.write(str1+ "<br/>");
	document.write(str1.toUpperCase());
}