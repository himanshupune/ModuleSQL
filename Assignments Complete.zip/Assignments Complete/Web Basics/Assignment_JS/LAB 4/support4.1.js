function dispArray(){
	var emp = new Array(6);
	emp[0] = "Tove";
	emp[1] = "Hege";
	emp[2] = "Stale";
	emp[3] = "Kai Jim";
	emp[4] = "Borge";
	emp[5] = "Vishesh";
	
	document.write("List of Employees<br/>");
	document.write("-------------------<br/>");
	
	for(var i=0;i<6;i++){
		document.write((i+1) + " " + emp[i]+ "<br/>");
	}
}