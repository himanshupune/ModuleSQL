function dispWindow(){
	var w = document.form5.width.value;
	var h = document.form5.height.value;
	var l = document.form5.left.value;
	var t = document.form5.top.value;
	//document.write(width);
	
	var mywindow=window.open("","_blank","width=w,height=h");
	mywindow.document.write("<html><head><title>New Window</title></head><body>");
	mywindow.document.write("This window is opened on clicking of the <b>new windows</b> button");
	mywindow.document.write("</body></html>");
}