function dispProducts(){
	var dollQuantity = document.form7.doll.value;
	var calcQuantity = document.form7.calc.value;
	var mobQuantity = document.form7.mob.value;
	var dvdQuantity = document.form7.dvd.value;
	var message = true;
	
	if(dollQuantity=="" || calcQuantity=="" || mobQuantity=="" || dvdQuantity==""){
		message = false;
	}
	
	/*var quantArray = new Array(4);
	var priceArray = new Array(4);
	var totalArray = new Array(4);
	
	for(var i=0;i<4;i++){
		quantArray
	}*/
	
	if(message==false){
		alert("no item selected");
	}
	
	else{
		
		var productWindow=window.open("","_blank","width=400,height=300");
	productWindow.document.write("<html><head><title>New Window</title></head><body>");
	productWindow.document.write("<b><center>INVOICE<center></b>");
	productWindow.document.write("<table border=\"1\">");
	productWindow.document.write("<td>Product</td><td>Quantity</td><td>Price</td><td>Total</td>")
	productWindow.document.write("<tr><td>Barbie Doll</td><td>"+dollQuantity+"</td><td>"+20+"</td><td>"+dollQuantity*20+"</td></tr>");
	productWindow.document.write("<tr><td>Calculator</td><td>"+calcQuantity+"</td><td>"+30+"</td><td>"+calcQuantity*30+"</td></tr>");
	productWindow.document.write("<tr><td>Barbie Doll</td><td>"+mobQuantity+"</td><td>"+40+"</td><td>"+dollQuantity*40+"</td></tr>");
	productWindow.document.write("<tr><td>Calculator</td><td>"+dvdQuantity+"</td><td>"+50+"</td><td>"+calcQuantity*50+"</td></tr>");
	productWindow.document.write("</table></body></html>");
		
	}
	
	
}