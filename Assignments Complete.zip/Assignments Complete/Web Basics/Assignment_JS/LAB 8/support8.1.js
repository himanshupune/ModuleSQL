function dispLoan(){
	
	var t1 = document.getElementById('amount').value;
	var t2 = document.getElementById('rate').value;
	var t3 = document.getElementById('time').value;
	
	var amountLoan = parseInt(t1);
	var rate = parseInt(t2);
	var time = parseInt(t3);
	
	var temp1 = amountLoan*rate*time/100;
	var temp2 = temp1 + amountLoan;
	var temp3 = temp2/(time*12);
	
	document.getElementById('monthly').value=temp3;
	document.getElementById('total').value=temp2;
	document.getElementById('interest').value=temp1;
	
	return false;
}