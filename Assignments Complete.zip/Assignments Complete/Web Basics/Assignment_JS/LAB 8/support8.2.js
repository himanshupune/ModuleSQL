function addProduct(){
	alert("Welcome");
	var data= document.form82.cato.value;
	
	if(data=="prod"){
		document.form82.produc.innerHTML="<option value='20000'>Television</option>"+
										"<option value='30000'>Laptop</option>"+
										"<option value='10000'>Phone</option>";
	}
	
	if(data=="groc"){
		document.form82.produc.innerHTML="<option value='40'>Soap</option>"+
										"<option value='90'>powder</option>";
	}
	
}

function myNewPrice(){
	var price = document.form82.produc.value;
	var quantity = document.form82.quant.value;
	
	var newPrice = parseInt(price);
	var quantitynew=parseInt(quantity);
	
	var totalPrice = newPrice*quantitynew;
	document.getElementById('tPrice').value=totalPrice;
	return false;
}













/*var state = document.myform.state.value;
var id = document.myform.eid.value;
var qualification = document.myform.qual.value;
var gender = document.myform.gender.value;
var messsage = true;

if(qualification=="select"){
message=false;
}
else{
message=true;
}

if(message==true){
	var mywindow=window.open("","","width=400,height=200");
	mywindow.document.write("<html><head><title>New Window</title></head><body>");
	mywindow.document.write("qualification is "+qualification);
	mywindow.document.write("qualification is "+id);
	mywindow.document.write("</body></html>");
}*/
