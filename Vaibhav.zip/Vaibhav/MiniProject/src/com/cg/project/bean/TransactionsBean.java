package com.cg.project.bean;

import java.util.Date;

public class TransactionsBean {
private long transactionId;
private String transDescription;
private Date dateOfTransaction;
private String transactionType;
private String transactionAmount;
private long accountNumber;

}
