package com.cg.project.bean;

public class UserBean {
private long accountId;
private long numberId;
private String loginPassword;
private String secretQuestion;
private String transactionPassword;
private String lockStatus;

}
