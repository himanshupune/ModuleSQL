package com.cg.project.client;

import java.util.Scanner;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.dao.BankingDAOImpl;

public class BankingClient {

	public static void main(String[] args) {
		BankingDAOImpl dao = new BankingDAOImpl();
		CustomerBean customer = new CustomerBean();
		AccountBean account = new AccountBean();
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
     /*System.out.println("Enter user id: ");
     String uid = sc.nextLine();
     System.out.println("ENTER your password");
     String pass = sc.nextLine();*/
     //dao.validate();
     System.out.println("ops to be done : 1.OpenAccount\n2.Transactions\n"
     		+ "3.DetailedStatement\n4.ChangePassword\n5.FundTransfer");
	String choice = sc.nextLine();
	switch(choice)
	{
	case "1": 
		System.out.println("Dear customer enter the name: ");
		String name = sc.nextLine();
		System.out.println("Enter emailId");
		String email = sc.nextLine();
		System.out.println("Enter address");
		String address = sc.nextLine();
		System.out.println("Enter PAN card no.");
		String pan = sc.nextLine();
		System.out.println("Enter the type of account you prefer\n1.Savings\n2.Current");
		String acctype = sc.nextLine();
		
		//String accType = sc.nextLine();
		
		//account.setAccountType(accType);
		
		customer.setCustomerName(name);
		customer.setAddress(address);
		customer.setEmail(email);
		customer.setPancard(pan);
		dao.openAccount(customer);
		break;
		
	case "2":
		System.out.println("Enter choice\n1.Deposit\n2.Withdrawl\n3.View Balance");
		String transChoice = sc.nextLine();
	switch(transChoice) {
	case "1":
		System.out.println("Enter account Id");
		int accId = sc.nextInt();
		customer.setAccountId(accId);
		//validate account id
		System.out.println("Enter account type");
		accType = sc.nextLine();
		System.out.println("Enter amount to be deposited");
		double amount = sc.nextDouble();
	}
		
		
	}

}
}