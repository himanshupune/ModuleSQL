package com.cg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.util.DBUtil;

public class BankingDAOImpl {

	//open account 

	public int openAccount(CustomerBean customerBean)
	{
		int count = 0;
		Connection conn =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO customer VALUES(acc_seq.nextval,?,?,?,?)");
		try{
			conn = DBUtil.createConnection();
		//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql);
			//pst.setLong(1,customerBean.getAccountId());
			pst.setString(1,customerBean.getCustomerName());
			pst.setString(2,customerBean.getEmail());
			pst.setString(3,customerBean.getAddress());
			pst.setString(4,customerBean.getPancard());

			//pstStudent.setString(6,bookingBean.getDateOfTransport());
			count = pst.executeUpdate();
		}catch(SQLException se)
		{
			se.printStackTrace();
		//	throw new BookingException("Record not inserted: ");
		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				//throw new BookingException("Problems in closing connection");
			}
		}
		System.out.println(count+" results affected");
		return count;
	}
	public int deposit(CustomerBean customer,double amount) throws SQLException {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
		String sql = "Select accountId from customer where accountId="+customer.getAccountId();
		pst = conn.prepareStatement(sql);
		pst=null;
		String sql1 = "Update AccountMaster set account_balance=account_balance+? where account_Id=?";
		pst = conn.prepareStatement(sql1);
		pst.setDouble(1, amount);
		pst.setLong(2, customer.getAccountId());
		}catch(SQLException se) {
			
		}
		return 0;
		
	}
	public void insertAccId() {
		Connection conn = null;
		PreparedStatement pst = null;
		try {
		String sql = "Select accountId from customer";
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			AccountBean account = new AccountBean(rs.getLong(1));
		}
	}catch(SQLException se) {
		
	}
	
}
}
